# mux_example
Multiplexer VHDL example: SFE401

Using ghdl, these compile with commands:
ghdl -e multiplexer.vhdl
ghdl -e mux
ghdl -a mux_tb.vhdl
ghdl -e mux_tb

runs with:
ghdl -r mux_tb

ghdl quick start guide is available at https://ghdl-rad.readthedocs.io/en/stable/using/QuickStartGuide.html
